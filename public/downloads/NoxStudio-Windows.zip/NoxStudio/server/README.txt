Nox dedicated server
====================

noxserver runs a Nox game with no window and no player of its own. It is the
host: players join it like any hosted game. Use it to keep a game online all the
time, on a spare computer or a server you rent.

  Windows:  noxserver.exe MyGame.exe
  Linux:    ./noxserver-linux MyGame.exe      (first: chmod +x noxserver-linux)

MyGame.exe is your game exported from Nox Studio (File > Export game, one .exe).
A game folder works too: noxserver.exe path\to\MyGame\game

Options:
  --port N      the port players come in on (normally 47800)
  --max N       the most players (normally 16)
  --name Name   the server's name
  --online      also list it on the Nox service

Players join with the join code it prints (same network), or with the server's
address and port from the internet, like 203.0.113.5:47800. On a rented server,
open that port (TCP) in its firewall. Ctrl+C stops it; saved data is written first.

On the server:
  - Loop:IsServer() is true, and Players.LocalPlayer is nil (it isn't a player).
  - Scripts run; LocalScripts and screens don't.
  - Everything the game turned on in File > Settings > Permissions is allowed
    (there's nobody to ask). Saves are kept on the server.

The Linux one needs a recent Linux (Ubuntu 24.04, Debian 13 or newer), 64-bit
(x86-64), and curl for web requests.
